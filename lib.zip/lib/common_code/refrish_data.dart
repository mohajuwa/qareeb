class RefreshData {
  final bool shouldRefresh;
  RefreshData(this.shouldRefresh);
}
